<?php $__env->startSection('sub-content'); ?>
  <div class='container'>
    <div class="card-body mb-5">
      <form method="POST" action="<?php echo e(route('user.profile.update')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group row">
          <label for="first_name" class="col-md-4 col-form-label text-md-right">First Name</label>

          <div class="col-md-6">
            <input id="first_name" type="text" class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" name="first_name" value="<?php echo e($user->first_name); ?>" required autofocus>

            <?php if($errors->has('first_name')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('first_name')); ?></strong>
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="last_name" class="col-md-4 col-form-label text-md-right">Last Name</label>

          <div class="col-md-6">
            <input id="last_name" type="text" class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" name="last_name" value="<?php echo e($user->last_name); ?>" required autofocus>

            <?php if($errors->has('last_name')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('last_name')); ?></strong>
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="username" class="col-md-4 col-form-label text-md-right">Username</label>

          <div class="col-md-6">
            <input id="username" type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e($user->username); ?>" required autofocus>

            <?php if($errors->has('username')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('username')); ?></strong>
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="email" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>

          <div class="col-md-6">
            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($user->email); ?>" required>

            <?php if($errors->has('email')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('email')); ?></strong>
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="phone_no" class="col-md-4 col-form-label text-md-right">Phone No</label>

          <div class="col-md-6">
            <input id="phone_no" type="text" class="form-control<?php echo e($errors->has('phone_no') ? ' is-invalid' : ''); ?>" name="phone_no" value="<?php echo e($user->phone_no); ?>" required>

            <?php if($errors->has('phone_no')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('phone_no')); ?></strong>
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="division_id" class="col-md-4 col-form-label text-md-right">Division</label>

          <div class="col-md-6">
            <select class="form-control" name="division_id">
              <option value="">Please select your division</option>
              <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($division->id); ?>" <?php echo e($user->division_id == $division->id ? 'selected' : ''); ?>><?php echo e($division->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="form-group row">
          <label for="district_id" class="col-md-4 col-form-label text-md-right">District</label>

          <div class="col-md-6">
            <select class="form-control" name="district_id">
              <option value="">Please select your district</option>
              <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($district->id); ?>" <?php echo e($user->district_id == $district->id ? 'selected' : ''); ?>><?php echo e($district->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label for="street_address" class="col-md-4 col-form-label text-md-right">Street Address</label>

          <div class="col-md-6">
            <input id="street_address" type="text" class="form-control<?php echo e($errors->has('street_address') ? ' is-invalid' : ''); ?>" name="street_address" value="<?php echo e($user->street_address); ?>" required>

            <?php if($errors->has('street_address')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('street_address')); ?></strong>
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="shipping_address" class="col-md-4 col-form-label text-md-right">Shipping Address (optional)</label>

          <div class="col-md-6">
            <textarea id="shipping_address" class="form-control<?php echo e($errors->has('shipping_address') ? ' is-invalid' : ''); ?>" rows="4" name="shipping_address"><?php echo e($user->shipping_address); ?></textarea>

            <?php if($errors->has('shipping_address')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('shipping_address')); ?></strong>
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="password" class="col-md-4 col-form-label text-md-right">New Password (optional)</label>

          <div class="col-md-6">
            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">

            <?php if($errors->has('password')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('password')); ?></strong>
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group row mb-0">
          <div class="col-md-6 offset-md-4">
            <button type="submit" class="btn btn-primary">
              Update Profile
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.pages.users.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>