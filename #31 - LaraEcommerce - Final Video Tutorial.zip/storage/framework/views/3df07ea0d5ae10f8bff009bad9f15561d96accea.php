<script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" ></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
