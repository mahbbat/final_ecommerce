<?php $__env->startSection('sub-content'); ?>
  <div class='container'>
    <h2>Welcome <?php echo e($user->first_name . ' '. $user->last_name); ?></h2>
    <p>You can change your profile and every informations here..</p>
    <hr>

    <div class="row">
      <div class="col-md-4">
        <div class="card card-body mt-2 pointer" onclick="location.href='<?php echo e(route('user.profile')); ?>'">
          <h3>Update Profile</h3>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.pages.users.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>